#!/bin/bash
#################################################################
#  Auto backup script by Ryan Studio <support@Ryan.id>        #
#                                                               #
#  Reselling this file, via any medium is strictly prohibited   #
#  Proprietary and confidential                                 #
#                                                               #
#  Contributors:                                                #
#  Ryan <xabhista19@gmail.com>                         #
#                                                               #
#  Link: https://Ryan.id                                       #
#                                                               #
#  December 28, 2021                                            #
#################################################################

rclone_path="/usr/bin/rclone"
dos2unix_path="/usr/bin/dos2unix"


if [ "$(id -u)" -ne 0 ]; then
    echo "Please execute this script as root."
    exit 1
fi

echo "Installing dependencies"

if [ -f "/usr/bin/apt-get" ]; then
    apt-get update -y
    apt-get -y install grep sed tar dos2unix pigz
elif [ -f "/usr/bin/dnf" ]; then
    dnf update -y
    dnf install grep sed tar dos2unix pigz -y
elif [ -f "/usr/bin/yum" ]; then
    yum update -y
    yum install grep sed tar dos2unix pigz -y
elif [ -f "/usr/bin/pacman" ]; then
    pacman -Syu
    pacman -S grep sed tar pigz dos2unix
elif [ -f "/usr/bin/zypper" ]; then
    zypper update -y
    zypper install -y grep sed tar pigz dos2unix
elif [ -f "/usr/bin/pkg" ]; then
    pkg update -fq
    pkg install -y grep sed tar pigz dos2unix
else
    echo "Unsupported OS"
    exit 1
fi

mkdir -p /etc/auto-backup

echo "Installing rclone.."
if [ ! -f ${rclone_path} ]; then
    curl https://rclone.org/install.sh | sudo bash
fi

echo -n "Enter your config path: "
read -r config_path

echo "Checking config"
dos2unix config/config.conf
dos2unix config/lang.conf
dos2unix src/backup.sh

sleep 2s
echo "Copying config..."
cp -v config/config.conf "${config_path}"


echo "Copying lang..."
cp -v config/lang.conf "${config_path}"
sleep 2s

echo "Checking backup script"
if [ ! -f "/usr/bin/backup" ]; then
    echo "Copying backup script..."
    cp -v src/backup.sh /usr/bin/backup
    chmod +x /usr/bin/backup
else
    echo "Backup script already exists, replacing..."
    cp -v src/backup.sh /usr/bin/backup
fi

echo; echo 'Installation has completed!'
echo 'Config files are located at "'"${config_path}"'"'
echo
echo "Auto Backup version 1.3.3"
echo "Copyright (C) 2021 - 2022, Ryan Studios <support@Ryan.id>"
echo

exit 0